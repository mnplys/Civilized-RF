# Manifesto

Commands are signals. Meaning emerges from constraint, timing, and decay.
