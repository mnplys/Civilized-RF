# Civilized RF

A speculative research repository exploring command systems, signals, and intent across physical, computational, and spatial layers.
