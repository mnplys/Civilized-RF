# Malformed Commands

When syntax fails but meaning persists.
