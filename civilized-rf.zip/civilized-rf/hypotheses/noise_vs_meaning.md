# Noise vs Meaning

Distinguishing entropy from information.
