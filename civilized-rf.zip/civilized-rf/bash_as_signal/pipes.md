# Pipes

Pipes as directed signal flow.
