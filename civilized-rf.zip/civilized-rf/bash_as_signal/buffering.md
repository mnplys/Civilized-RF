# Buffering

Latency, queues, and memory pressure.
