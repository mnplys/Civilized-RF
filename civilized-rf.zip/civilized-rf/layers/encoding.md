# Encoding

Symbol systems as negotiated compression.
