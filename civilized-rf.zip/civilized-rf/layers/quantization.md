# Quantization

How continuous signals become discrete meaning.
