# Physical Signals

RF, voltage, and noise as the substrate of computation.
