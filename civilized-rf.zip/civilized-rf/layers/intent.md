# Intent

Human and machine intention as directional signal bias.
