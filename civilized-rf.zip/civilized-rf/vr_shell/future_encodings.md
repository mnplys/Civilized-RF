# Future Encodings

Beyond text and speech.
