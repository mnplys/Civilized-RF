# Non-Text Commands

Gesture, gaze, and spatial input.
